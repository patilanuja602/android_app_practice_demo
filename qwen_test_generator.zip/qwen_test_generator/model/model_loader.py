"""Loads a Qwen3 model from a LOCAL directory only. Uses the GPU if present, otherwise falls back to CPU."""
import os
from pathlib import Path

os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

DEFAULT_MODEL_PATH = os.environ.get("QWEN_MODEL_PATH", "./models/Qwen3-32B")


class ModelLoadError(Exception):
    """Base class for model loading problems."""


class ModelNotFoundError(ModelLoadError):
    pass


class InsufficientMemoryError(ModelLoadError):
    pass


def describe_device() -> str:
    if torch.cuda.is_available():
        names = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
        return "GPU (CUDA): " + ", ".join(names)
    return "CPU (no CUDA GPU detected - generation will be slow)"


def _model_size_gb(path: Path) -> float:
    return sum(f.stat().st_size for f in path.glob("*.safetensors")) / 1e9


def load_model(model_path: str = DEFAULT_MODEL_PATH, quantization: str = "none"):
    """Auto-selects device: CUDA GPU(s) if available, else CPU.
    quantization: 'none' (default), '8bit' or '4bit' (GPU + bitsandbytes only)."""
    path = Path(model_path).expanduser()
    if not path.is_dir() or not (path / "config.json").exists():
        raise ModelNotFoundError(
            f"Model not found at '{path}'. Put the model files in that folder or set QWEN_MODEL_PATH. See README."
        )

    use_gpu = torch.cuda.is_available()
    kwargs = dict(local_files_only=True, dtype=torch.bfloat16)

    if use_gpu:
        kwargs["device_map"] = "auto"          # spreads across GPUs, spills to CPU RAM if needed
        if quantization in ("4bit", "8bit"):
            try:
                from transformers import BitsAndBytesConfig
                kwargs["quantization_config"] = (
                    BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                       bnb_4bit_compute_dtype=torch.bfloat16)
                    if quantization == "4bit" else BitsAndBytesConfig(load_in_8bit=True))
            except Exception as e:  # noqa: BLE001
                raise ModelLoadError(f"Quantization '{quantization}' requires bitsandbytes: {e}") from e
    else:
        if quantization != "none":
            raise ModelLoadError("4bit/8bit quantization needs a CUDA GPU. Set Precision to 'none' on CPU.")
        # CPU fallback: check RAM first so we fail with a clear message instead of freezing the machine
        try:
            import psutil
            need, have = _model_size_gb(path), psutil.virtual_memory().available / 1e9
            if need and have < need * 1.1:
                raise InsufficientMemoryError(
                    f"CPU mode: model needs ~{need:.0f}GB RAM but only ~{have:.0f}GB is available. "
                    f"Use a smaller model (e.g. Qwen3-4B / Qwen3-8B) via the model path."
                )
        except ImportError:
            pass

    try:
        tokenizer = AutoTokenizer.from_pretrained(str(path), local_files_only=True)
        model = AutoModelForCausalLM.from_pretrained(str(path), **kwargs)
        if not use_gpu:
            model.to("cpu")
        model.eval()
        return model, tokenizer
    except InsufficientMemoryError:
        raise
    except torch.cuda.OutOfMemoryError as e:
        raise InsufficientMemoryError(
            "GPU ran out of memory while loading. Use more GPU memory, a smaller model, or 4bit/8bit precision "
            "(recorded in the experiment)."
        ) from e
    except (RuntimeError, MemoryError) as e:
        if "out of memory" in str(e).lower() or isinstance(e, MemoryError):
            raise InsufficientMemoryError(f"Out of memory while loading the model: {e}") from e
        raise ModelLoadError(f"Model loading failed: {e}") from e
    except Exception as e:  # noqa: BLE001
        raise ModelLoadError(f"Model loading failed: {type(e).__name__}: {e}") from e
